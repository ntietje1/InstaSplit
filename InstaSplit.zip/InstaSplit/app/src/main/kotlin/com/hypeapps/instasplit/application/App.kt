package com.hypeapps.instasplit.application

import android.app.Application

class App : Application() {
    val appContainer: AppContainer = AppContainer()
}