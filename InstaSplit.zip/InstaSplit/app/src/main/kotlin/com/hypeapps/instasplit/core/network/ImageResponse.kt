package com.hypeapps.instasplit.core.network

data class ImageResponse(val url: String)